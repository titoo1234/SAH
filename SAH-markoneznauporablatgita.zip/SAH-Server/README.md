# SAH
Projekt pri PROG3, igra šah.
